# -*- coding: utf-8 -*-

__pkgname__ = "python-iptables"
__version__ = "0.6.0-dev"
